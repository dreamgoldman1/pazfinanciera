
AUTHORS
-------
Jimmy Berry ("boombatower", http://drupal.org/user/214218)
John Franklin (https://drupal.org/user/683430)
	-- with gracious help from the community at large.

PROJECT PAGE
------------
If you need more information, have an issue, or feature request please
visit the project page at: http://drupal.org/project/click_heatmap.

DESCRIPTION
-----------
The Click Heatmap module provides integration between Drupal and the ClickHeat
library. The module itself does not record any data or generate click heatmaps.
Instead the module provides a limited Drupal related scope and injects the
the Javascript necessary to record the click data.
