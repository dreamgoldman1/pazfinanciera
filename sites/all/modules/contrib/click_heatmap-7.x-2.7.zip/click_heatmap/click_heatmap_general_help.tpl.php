<?php

/**
 * @file
 * Provides basic help for the click_heatmap module.
 *
 * Copyright © 2011 John Franklin
 */
?>
<p>Needs to be written.</p>