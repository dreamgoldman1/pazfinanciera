<?php define('CLICKHEAT_VERSION', '1.14'); ?>
